<?php

namespace App\Http\Controllers;

use App\Models\Client;
use App\Models\Policy;
use App\Models\PolicyBenefit;
use App\Models\Plan;
use App\Models\InsuranceCompany;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class ClientController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $insuranceCompanyId = auth()->user()->insurance_company_id;
        
        // Get all clients (both with and without policies for this insurance company)
        // For now, show all clients, but filter policies by insurance company
        $clients = Client::with(['policies' => function($query) use ($insuranceCompanyId) {
                $query->where('insurance_company_id', $insuranceCompanyId);
            }, 'principalMember', 'plan'])
            ->latest()
            ->paginate(15);
            
        return view('clients.index', compact('clients'));
    }

    /**
     * Build validation rules based on insurance company settings
     */
    private function buildValidationRules(InsuranceCompany $insuranceCompany, bool $isUpdate = false, $clientId = null): array
    {
        $requiredFields = $insuranceCompany->getRequiredFields();
        
        // Base rules that are always the same
        $rules = [
            'type' => 'required|in:principal,dependent',
            'principal_member_id' => 'required_if:type,dependent|nullable|exists:clients,id',
            'plan_id' => 'required_if:type,principal|nullable|exists:plans,id',
            'desired_start_date' => 'nullable|date',
            'number_of_dependents' => 'nullable|integer|min:0|max:20',
            'has_deductible' => 'nullable|boolean',
            'deductible_amount' => 'nullable|numeric|min:0',
            'copay_amount' => 'nullable|numeric|min:0',
            'coinsurance_percentage' => 'nullable|numeric|min:0|max:100',
            'copay_max_limit' => 'nullable|numeric|min:0',
            'copay_contributes_to_deductible' => 'nullable|boolean',
            'coinsurance_contributes_to_deductible' => 'nullable|boolean',
            'telemedicine_only' => 'nullable|boolean',
            'is_active' => 'nullable|boolean',
        ];
        
        // Dynamic rules based on required fields
        $fieldRules = [
            'surname' => in_array('surname', $requiredFields) ? 'required|string|max:255' : 'nullable|string|max:255',
            'first_name' => 'required|string|max:255', // Always required
            'other_names' => in_array('other_names', $requiredFields) ? 'required|string|max:255' : 'nullable|string|max:255',
            'title' => in_array('title', $requiredFields) ? 'required|string|max:50' : 'nullable|string|max:50',
            'id_passport_no' => $isUpdate 
                ? 'required|string|max:255|unique:clients,id_passport_no,' . $clientId
                : 'required|string|max:255|unique:clients,id_passport_no', // Always required
            'gender' => in_array('gender', $requiredFields) ? 'required|in:Male,Female' : 'nullable|in:Male,Female',
            'tin' => in_array('tin', $requiredFields) ? 'required|string|max:255' : 'nullable|string|max:255',
            'date_of_birth' => in_array('date_of_birth', $requiredFields) ? 'required|date' : 'nullable|date',
            'marital_status' => in_array('marital_status', $requiredFields) ? 'required|in:Single,Married,Divorced,Widowed' : 'nullable|in:Single,Married,Divorced,Widowed',
            'height' => in_array('height', $requiredFields) ? 'required|string|max:50' : 'nullable|string|max:50',
            'weight' => in_array('weight', $requiredFields) ? 'required|string|max:50' : 'nullable|string|max:50',
            'employer_name' => in_array('employer_name', $requiredFields) ? 'required|string|max:255' : 'nullable|string|max:255',
            'occupation' => in_array('occupation', $requiredFields) ? 'required|string|max:255' : 'nullable|string|max:255',
            'nationality' => in_array('nationality', $requiredFields) ? 'required|string|max:255' : 'nullable|string|max:255',
            'home_physical_address' => in_array('home_physical_address', $requiredFields) ? 'required|string|max:500' : 'nullable|string|max:500',
            'office_physical_address' => in_array('office_physical_address', $requiredFields) ? 'required|string|max:500' : 'nullable|string|max:500',
            'home_telephone' => in_array('home_telephone', $requiredFields) ? 'required|string|max:50' : 'nullable|string|max:50',
            'office_telephone' => in_array('office_telephone', $requiredFields) ? 'required|string|max:50' : 'nullable|string|max:50',
            'cell_phone' => in_array('cell_phone', $requiredFields) ? 'required|string|max:50' : 'nullable|string|max:50',
            'whatsapp_line' => in_array('whatsapp_line', $requiredFields) ? 'required|string|max:50' : 'nullable|string|max:50',
            'email' => in_array('email', $requiredFields) ? 'required|email|max:255' : 'nullable|email|max:255',
            'relation_to_principal' => 'nullable|string|max:255',
            'next_of_kin_surname' => in_array('next_of_kin_surname', $requiredFields) ? 'required|string|max:255' : 'nullable|string|max:255',
            'next_of_kin_first_name' => in_array('next_of_kin_first_name', $requiredFields) ? 'required|string|max:255' : 'nullable|string|max:255',
            'next_of_kin_other_names' => in_array('next_of_kin_other_names', $requiredFields) ? 'required|string|max:255' : 'nullable|string|max:255',
            'next_of_kin_title' => in_array('next_of_kin_title', $requiredFields) ? 'required|string|max:50' : 'nullable|string|max:50',
            'next_of_kin_relation' => in_array('next_of_kin_relation', $requiredFields) ? 'required|string|max:255' : 'nullable|string|max:255',
            'next_of_kin_id_passport_no' => in_array('next_of_kin_id_passport_no', $requiredFields) ? 'required|string|max:255' : 'nullable|string|max:255',
            'next_of_kin_cell_phone' => in_array('next_of_kin_cell_phone', $requiredFields) ? 'required|string|max:50' : 'nullable|string|max:50',
            'next_of_kin_email' => in_array('next_of_kin_email', $requiredFields) ? 'required|email|max:255' : 'nullable|email|max:255',
            'next_of_kin_post_address' => in_array('next_of_kin_post_address', $requiredFields) ? 'required|string|max:500' : 'nullable|string|max:500',
            'next_of_kin_physical_address' => in_array('next_of_kin_physical_address', $requiredFields) ? 'required|string|max:500' : 'nullable|string|max:500',
        ];
        
        return array_merge($rules, $fieldRules);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $user = auth()->user();
        if (!$user->insuranceCompany) {
            return redirect()->route('dashboard')->with('error', 'You must be associated with an insurance company to create clients.');
        }

        $medicalQuestions = \App\Models\MedicalQuestion::where('insurance_company_id', $user->insurance_company_id)
            ->where('is_active', true)
            ->orderBy('order')
            ->orderBy('id')
            ->get();
        
        $insuranceCompany = $user->insuranceCompany;
        $requiredFields = $insuranceCompany ? $insuranceCompany->getRequiredFields() : ['first_name', 'id_passport_no'];
        
        return view('clients.create', compact('medicalQuestions', 'requiredFields', 'insuranceCompany'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $user = auth()->user();
        $insuranceCompany = $user->insuranceCompany;
        if (!$insuranceCompany) {
            return redirect()->back()->with('error', 'You must be associated with an insurance company.');
        }

        $validated = $request->validate($this->buildValidationRules($insuranceCompany));

        // Handle checkboxes
        $validated['has_deductible'] = $request->boolean('has_deductible');
        $validated['telemedicine_only'] = $request->boolean('telemedicine_only');
        $validated['is_active'] = $request->boolean('is_active');

        // Set principal_member_id to null if not dependent
        if ($validated['type'] === 'principal') {
            $validated['principal_member_id'] = null;
            $validated['relation_to_principal'] = null;
        }

        $client = Client::create($validated);
        $policyNumber = null;
        
        // Initialize monetary adjustment variables
        $premiumAdjustment = 0;
        $deductibleAdjustment = 0;

        // If plan is selected and client is principal, create policy and policy benefits
        if ($validated['plan_id'] && $validated['type'] === 'principal') {
            $plan = Plan::with('serviceCategories')->findOrFail($validated['plan_id']);
            
            // Generate unique policy number
            $policyNumber = $this->generatePolicyNumber();
            
            // Set policy dates
            $desiredStartDate = $validated['desired_start_date'] ? \Carbon\Carbon::parse($validated['desired_start_date']) : now();
            $inceptionDate = $desiredStartDate;
            $expiryDate = $inceptionDate->copy()->addYear();
            
            // Map plan name to plan_type enum value (must match enum values)
            $planTypeMap = [
                'Prestige' => 'Prestige',
                'Executive' => 'Executive',
                'Standard Plus' => 'Standard Plus',
                'Standard' => 'Standard',
                'Regular' => 'Regular',
                'Budget' => 'Budget',
            ];
            $planType = $planTypeMap[$plan->name] ?? 'Standard'; // Default to 'Standard' if not found
            
            // Get selected benefits from request
            $selectedBenefits = $request->input('selected_benefits.' . $validated['plan_id'], []);
            
            // Get number of dependents
            $numberOfDependents = $validated['number_of_dependents'] ?? 0;
            
            // Calculate premium based on selected benefits BEFORE creating policy
            $basePremium = 0;
            
            // Calculate premium from selected service categories
            foreach ($plan->serviceCategories as $serviceCategory) {
                $pivot = $serviceCategory->pivot;
                
                // Check if this benefit was selected by the user
                $isSelected = isset($selectedBenefits[$serviceCategory->id]);
                
                // Inpatient is mandatory, so always include it if it exists
                $isInpatient = $serviceCategory->name === 'Inpatient';
                
                // Add base amount (what client pays) to premium if selected/enabled and has an amount
                if (($isSelected || $isInpatient) && $pivot->is_enabled && $pivot->base_amount) {
                    $basePremium += $pivot->base_amount;
                }
            }
            
            // Calculate premium based on plan's calculation method
            $calculationMethod = $plan->premium_calculation_method ?? 'benefit_based';
            
            if ($calculationMethod === 'fixed') {
                // Use base premium only
                $basePremium = $plan->base_premium ?? 0;
            } elseif ($calculationMethod === 'hybrid') {
                // Base premium + benefit amounts
                $basePremium = ($plan->base_premium ?? 0) + $basePremium;
            }
            // else 'benefit_based' - already calculated above
            
            // Calculate dependents premium using tiered multipliers
            $dependentsPremium = $plan->calculateDependentPremium($basePremium, $numberOfDependents);
            
            // Subtotal premium (principal + dependents)
            $subtotalPremium = $basePremium + $dependentsPremium;
            
            // Calculate insurance training levy using plan's percentage
            $trainingLevyPercentage = ($plan->insurance_training_levy_percentage ?? 0.50) / 100;
            $insuranceTrainingLevy = $subtotalPremium * $trainingLevyPercentage;
            
            // Stamp duty from plan settings
            $stampDuty = $plan->stamp_duty_amount ?? 35000;
            
            // Calculate monetary impact from medical questions
            $coverageLimitAdjustments = [];
            
            if ($request->has('medical_questions')) {
                foreach ($request->medical_questions as $questionId => $responseData) {
                    $question = \App\Models\MedicalQuestion::find($questionId);
                    if (!$question || !$question->has_monetary_impact || $question->monetary_impact_type === 'none') {
                        continue;
                    }
                    
                    $response = strtolower(trim($responseData['response'] ?? ''));
                    $appliesTo = strtolower(trim($question->monetary_impact_applies_to_response ?? 'yes'));
                    
                    // Check if response matches the trigger
                    $shouldApply = false;
                    if ($question->question_type === 'yes_no') {
                        $shouldApply = ($response === $appliesTo);
                    } else {
                        // For text/date/number, check if response matches or contains the trigger
                        $shouldApply = ($response === $appliesTo || str_contains($response, $appliesTo));
                    }
                    
                    if ($shouldApply && $question->monetary_impact_amount) {
                        $impactAmount = $question->monetary_impact_amount;
                        
                        if ($question->monetary_impact_type === 'premium_adjustment') {
                            if ($question->monetary_impact_is_percentage) {
                                // Percentage of base premium
                                $premiumAdjustment += ($basePremium * $impactAmount / 100);
                            } else {
                                // Fixed amount
                                $premiumAdjustment += $impactAmount;
                            }
                        } elseif ($question->monetary_impact_type === 'deductible_adjustment') {
                            if ($question->monetary_impact_is_percentage) {
                                // Percentage adjustment (would need base deductible, but we'll use fixed for now)
                                $deductibleAdjustment += $impactAmount;
                            } else {
                                // Fixed amount
                                $deductibleAdjustment += $impactAmount;
                            }
                        } elseif ($question->monetary_impact_type === 'coverage_limit_adjustment') {
                            // Store for later use (could adjust annual/lifetime limits)
                            $coverageLimitAdjustments[] = [
                                'amount' => $impactAmount,
                                'is_percentage' => $question->monetary_impact_is_percentage,
                            ];
                        }
                    }
                }
            }
            
            // Apply premium adjustment
            $subtotalPremium += $premiumAdjustment;
            
            // Recalculate training levy after premium adjustment
            $insuranceTrainingLevy = $subtotalPremium * $trainingLevyPercentage;
            
            // Total premium due = subtotal premium + levy + stamp duty
            $totalPremiumDue = $subtotalPremium + $insuranceTrainingLevy + $stampDuty;
            
            // Apply deductible adjustment if applicable
            $finalDeductibleAmount = null;
            if (($validated['has_deductible'] ?? false) && isset($validated['deductible_amount'])) {
                $finalDeductibleAmount = $validated['deductible_amount'] + $deductibleAdjustment;
            } elseif ($deductibleAdjustment > 0) {
                // If no deductible was set but adjustment exists, set it
                $finalDeductibleAmount = $deductibleAdjustment;
            }
            
            // Get insurance company defaults for contribution flags
            $insuranceCompany = auth()->user()->insuranceCompany;
            $defaultCopayContributes = $insuranceCompany ? $insuranceCompany->copay_contributes_to_deductible : false;
            $defaultCoinsuranceContributes = $insuranceCompany ? $insuranceCompany->coinsurance_contributes_to_deductible : false;
            
            // Use provided values or fall back to company defaults
            $copayContributes = isset($validated['copay_contributes_to_deductible']) 
                ? (bool)$validated['copay_contributes_to_deductible'] 
                : $defaultCopayContributes;
            $coinsuranceContributes = isset($validated['coinsurance_contributes_to_deductible']) 
                ? (bool)$validated['coinsurance_contributes_to_deductible'] 
                : $defaultCoinsuranceContributes;
            
            // Create policy with calculated premium
            $policy = Policy::create([
                'policy_number' => $policyNumber,
                'insurance_company_id' => auth()->user()->insurance_company_id,
                'principal_member_id' => $client->id,
                'plan_type' => $planType,
                'inception_date' => $inceptionDate,
                'expiry_date' => $expiryDate,
                'desired_start_date' => $desiredStartDate,
                'total_premium' => $subtotalPremium, // Includes principal + dependents + medical question adjustments
                'insurance_training_levy' => $insuranceTrainingLevy,
                'stamp_duty' => $stampDuty,
                'total_premium_due' => $totalPremiumDue,
                'status' => 'active',
                'is_paid' => false,
                'has_deductible' => $validated['has_deductible'] ?? false,
                'copay_amount' => $validated['copay_amount'] ?? null,
                'coinsurance_percentage' => $validated['coinsurance_percentage'] ?? null,
                'deductible_amount' => $finalDeductibleAmount,
                'copay_max_limit' => $validated['copay_max_limit'] ?? null,
                'copay_contributes_to_deductible' => $copayContributes,
                'coinsurance_contributes_to_deductible' => $coinsuranceContributes,
                'telemedicine_only' => $validated['telemedicine_only'] ?? false,
            ]);
            
            // Create policy benefits only for selected service categories
            foreach ($plan->serviceCategories as $serviceCategory) {
                $pivot = $serviceCategory->pivot;
                
                // Check if this benefit was selected by the user
                $isSelected = isset($selectedBenefits[$serviceCategory->id]);
                
                // Inpatient is mandatory, so always create it if it exists
                $isInpatient = $serviceCategory->name === 'Inpatient';
                
                // Only create benefit if it's selected (or mandatory like Inpatient), enabled, and has an amount
                if (($isSelected || $isInpatient) && $pivot->is_enabled && $pivot->benefit_amount) {
                    $benefitData = [
                        'policy_id' => $policy->id,
                        'service_category_id' => $serviceCategory->id,
                        'benefit_amount' => $pivot->benefit_amount,
                        'used_amount' => 0,
                        'remaining_amount' => $pivot->benefit_amount,
                        'copay_percentage' => $pivot->copay_percentage ?? 0,
                        'deductible_amount' => 0, // Not used anymore, but keep for compatibility
                        'is_enabled' => true,
                        'effective_date' => $inceptionDate,
                        'expiry_date' => $expiryDate,
                    ];
                    
                    // Only set hospital cash fields if it's Hospital Cash
                    if ($serviceCategory->name === 'Hospital Cash') {
                        $benefitData['hospital_cash_per_day'] = $pivot->benefit_amount;
                        $benefitData['hospital_cash_max_days'] = 30;
                    } elseif ($serviceCategory->name === 'Life Cover') {
                        $benefitData['life_cover_amount'] = $pivot->benefit_amount;
                    }
                    
                    PolicyBenefit::create($benefitData);
                }
            }
        }

        // Save medical question responses
        if ($request->has('medical_questions')) {
            foreach ($request->medical_questions as $questionId => $responseData) {
                $question = \App\Models\MedicalQuestion::find($questionId);
                if (!$question) {
                    continue;
                }

                $response = $responseData['response'] ?? null;
                $additionalInfo = $responseData['additional_info'] ?? null;

                // Handle medication table data if present
                if ($question->additional_info_type === 'table' && $request->has("medications.{$questionId}")) {
                    $medications = $request->input("medications.{$questionId}", []);
                    // Filter out empty rows
                    $medications = array_filter($medications, function($med) {
                        return !empty($med['applicant_name']) || !empty($med['medication']) || !empty($med['diagnosis']);
                    });
                    $additionalInfo = !empty($medications) ? json_encode(array_values($medications)) : null;
                } elseif (is_string($additionalInfo)) {
                    // Try to decode if it's already JSON, otherwise store as is
                    $decoded = json_decode($additionalInfo, true);
                    $additionalInfo = $decoded !== null ? $decoded : $additionalInfo;
                }

                // Check if response triggers exclusion
                $triggersExclusion = $question->triggersExclusion($response ?? '');

                \App\Models\MedicalQuestionResponse::create([
                    'client_id' => $client->id,
                    'medical_question_id' => $questionId,
                    'response' => $response,
                    'additional_info' => is_array($additionalInfo) ? $additionalInfo : ($additionalInfo ? json_decode($additionalInfo, true) : null),
                    'triggers_exclusion' => $triggersExclusion,
                ]);
            }
        }

        // Check if client has exclusions and add warning
        $hasExclusions = $client->hasExclusions();
        
        // Build success message with policy details
        $successMessage = 'Client created successfully';
        
        if ($validated['plan_id'] && $validated['type'] === 'principal' && $policyNumber) {
            $policy = Policy::where('policy_number', $policyNumber)->first();
            if ($policy) {
                $numberOfDependents = $validated['number_of_dependents'] ?? 0;
                $dependentsText = $numberOfDependents > 0 ? " (including {$numberOfDependents} " . ($numberOfDependents == 1 ? 'dependent' : 'dependents') . ")" : '';
                $successMessage .= sprintf(
                    '. Policy %s has been created%s. Total Premium Due: UGX %s (Premium: UGX %s, Training Levy: UGX %s, Stamp Duty: UGX %s)',
                    $policyNumber,
                    $dependentsText,
                    number_format($policy->total_premium_due, 2),
                    number_format($policy->total_premium, 2),
                    number_format($policy->insurance_training_levy, 2),
                    number_format($policy->stamp_duty, 2)
                );
                
                // Add monetary adjustment information
                if ($premiumAdjustment != 0) {
                    $adjustmentType = $premiumAdjustment > 0 ? 'increased' : 'decreased';
                    $successMessage .= sprintf(
                        '. Premium %s by UGX %s due to medical questionnaire responses',
                        $adjustmentType,
                        number_format(abs($premiumAdjustment), 2)
                    );
                }
                
                if ($deductibleAdjustment != 0) {
                    $adjustmentType = $deductibleAdjustment > 0 ? 'increased' : 'decreased';
                    $successMessage .= sprintf(
                        '. Deductible %s by UGX %s due to medical questionnaire responses',
                        $adjustmentType,
                        number_format(abs($deductibleAdjustment), 2)
                    );
                }
            } else {
                $successMessage .= '. Policy ' . $policyNumber . ' has been created.';
            }
        }
        
        if ($hasExclusions) {
            $successMessage .= ' WARNING: This client has responses that trigger exclusion list criteria.';
        }

        return redirect()->route('clients.index')
            ->with('success', $successMessage)
            ->with('has_exclusions', $hasExclusions);
    }

    /**
     * Generate a unique policy number based on insurance company settings
     */
    private function generatePolicyNumber(): string
    {
        $insuranceCompany = auth()->user()->insuranceCompany;
        
        // Get settings with defaults
        $format = $insuranceCompany->policy_number_format ?? '{COMPANY}-{YEAR}{MONTH}{DAY}-{RANDOM}';
        $randomLength = $insuranceCompany->policy_number_random_length ?? 6;
        $randomType = $insuranceCompany->policy_number_random_type ?? 'alphanumeric';
        $companyCodeLength = $insuranceCompany->policy_number_company_code_length ?? 3;
        
        // Generate company code prefix
        $companyCode = strtoupper(substr($insuranceCompany->code ?? 'INS', 0, $companyCodeLength));
        
        // Generate random part based on type
        $randomPart = $this->generateRandomPart($randomLength, $randomType);
        
        // Replace placeholders in format
        $policyNumber = $format;
        $policyNumber = str_replace('{COMPANY}', $companyCode, $policyNumber);
        $policyNumber = str_replace('{YEAR}', now()->format('Y'), $policyNumber);
        $policyNumber = str_replace('{MONTH}', now()->format('m'), $policyNumber);
        $policyNumber = str_replace('{DAY}', now()->format('d'), $policyNumber);
        $policyNumber = str_replace('{YEAR2}', now()->format('y'), $policyNumber); // 2-digit year
        $policyNumber = str_replace('{RANDOM}', $randomPart, $policyNumber);
        
        // Ensure uniqueness
        $attempts = 0;
        $maxAttempts = 100;
        $originalPolicyNumber = $policyNumber;
        
        while (Policy::where('policy_number', $policyNumber)->exists()) {
            $randomPart = $this->generateRandomPart($randomLength, $randomType);
            $policyNumber = str_replace('{RANDOM}', $randomPart, $originalPolicyNumber);
            $policyNumber = str_replace('{COMPANY}', $companyCode, $policyNumber);
            $policyNumber = str_replace('{YEAR}', now()->format('Y'), $policyNumber);
            $policyNumber = str_replace('{MONTH}', now()->format('m'), $policyNumber);
            $policyNumber = str_replace('{DAY}', now()->format('d'), $policyNumber);
            $policyNumber = str_replace('{YEAR2}', now()->format('y'), $policyNumber);
            
            $attempts++;
            if ($attempts > $maxAttempts) {
                throw new \Exception('Unable to generate unique policy number after multiple attempts.');
            }
        }
        
        return $policyNumber;
    }
    
    /**
     * Generate random part based on type
     */
    private function generateRandomPart(int $length, string $type): string
    {
        switch ($type) {
            case 'numeric':
                $characters = '0123456789';
                break;
            case 'alphabetic':
                $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
                break;
            case 'alphanumeric':
            default:
                $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
                break;
        }
        
        $random = '';
        for ($i = 0; $i < $length; $i++) {
            $random .= $characters[rand(0, strlen($characters) - 1)];
        }
        
        return $random;
    }

    /**
     * Display the specified resource.
     */
    public function show(Client $client)
    {
        $client->load([
            'principalMember', 
            'dependents', 
            'policies.insuranceCompany',
            'policies.benefits.serviceCategory',
            'medicalQuestionResponses.question',
            'plan'
        ]);
        return view('clients.show', compact('client'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Client $client)
    {
        $principals = Client::where('type', 'principal')
            ->where('id', '!=', $client->id)
            ->get();
        
        $user = auth()->user();
        if (!$user->insuranceCompany) {
            return redirect()->route('dashboard')->with('error', 'You must be associated with an insurance company to edit clients.');
        }

        $medicalQuestions = \App\Models\MedicalQuestion::where('insurance_company_id', $user->insurance_company_id)
            ->where('is_active', true)
            ->orderBy('order')
            ->orderBy('id')
            ->get();
        
        // Load existing responses and policy
        $client->load(['medicalQuestionResponses', 'policies']);
        
        $insuranceCompany = $user->insuranceCompany;
        $requiredFields = $insuranceCompany ? $insuranceCompany->getRequiredFields() : ['first_name', 'id_passport_no'];
        
        return view('clients.edit', compact('client', 'principals', 'medicalQuestions', 'requiredFields', 'insuranceCompany'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Client $client)
    {
        $user = auth()->user();
        $insuranceCompany = $user->insuranceCompany;
        if (!$insuranceCompany) {
            return redirect()->back()->with('error', 'You must be associated with an insurance company.');
        }

        $validated = $request->validate($this->buildValidationRules($insuranceCompany, true, $client->id));

        // Handle checkboxes
        $validated['has_deductible'] = $request->boolean('has_deductible');
        $validated['telemedicine_only'] = $request->boolean('telemedicine_only');
        $validated['is_active'] = $request->boolean('is_active');

        // Set principal_member_id to null if not dependent
        if ($validated['type'] === 'principal') {
            $validated['principal_member_id'] = null;
            $validated['relation_to_principal'] = null;
        }

        // Handle checkboxes
        $validated['has_deductible'] = $request->boolean('has_deductible');
        $validated['telemedicine_only'] = $request->boolean('telemedicine_only');
        $validated['is_active'] = $request->boolean('is_active');

        // Set principal_member_id to null if not dependent
        if ($validated['type'] === 'principal') {
            $validated['principal_member_id'] = null;
            $validated['relation_to_principal'] = null;
        }

        $client->update($validated);

        // Update policy if client is principal and has a policy
        if ($validated['type'] === 'principal' && $client->policies()->exists()) {
            $policy = $client->policies()->first();
            
            // Get insurance company defaults for contribution flags
            $insuranceCompany = auth()->user()->insuranceCompany;
            $defaultCopayContributes = $insuranceCompany ? $insuranceCompany->copay_contributes_to_deductible : false;
            $defaultCoinsuranceContributes = $insuranceCompany ? $insuranceCompany->coinsurance_contributes_to_deductible : false;
            
            // Use provided values or fall back to company defaults (or keep existing policy value)
            $copayContributes = isset($validated['copay_contributes_to_deductible']) 
                ? (bool)$validated['copay_contributes_to_deductible'] 
                : ($policy->copay_contributes_to_deductible ?? $defaultCopayContributes);
            $coinsuranceContributes = isset($validated['coinsurance_contributes_to_deductible']) 
                ? (bool)$validated['coinsurance_contributes_to_deductible'] 
                : ($policy->coinsurance_contributes_to_deductible ?? $defaultCoinsuranceContributes);
            
            $policy->update([
                'has_deductible' => $validated['has_deductible'] ?? false,
                'copay_amount' => $validated['copay_amount'] ?? null,
                'coinsurance_percentage' => $validated['coinsurance_percentage'] ?? null,
                'deductible_amount' => ($validated['has_deductible'] ?? false) ? ($validated['deductible_amount'] ?? null) : null,
                'copay_max_limit' => $validated['copay_max_limit'] ?? null,
                'copay_contributes_to_deductible' => $copayContributes,
                'coinsurance_contributes_to_deductible' => $coinsuranceContributes,
                'telemedicine_only' => $validated['telemedicine_only'] ?? false,
            ]);
        }

        // Update medical question responses
        if ($request->has('medical_questions')) {
            foreach ($request->medical_questions as $questionId => $responseData) {
                $question = \App\Models\MedicalQuestion::find($questionId);
                if (!$question) {
                    continue;
                }

                $response = $responseData['response'] ?? null;
                $additionalInfo = $responseData['additional_info'] ?? null;

                // Handle medication table data if present
                if ($question->additional_info_type === 'table' && $request->has("medications.{$questionId}")) {
                    $medications = $request->input("medications.{$questionId}", []);
                    // Filter out empty rows
                    $medications = array_filter($medications, function($med) {
                        return !empty($med['applicant_name']) || !empty($med['medication']) || !empty($med['diagnosis']);
                    });
                    $additionalInfo = !empty($medications) ? json_encode(array_values($medications)) : null;
                } elseif (is_string($additionalInfo)) {
                    // Try to decode if it's already JSON, otherwise store as is
                    $decoded = json_decode($additionalInfo, true);
                    $additionalInfo = $decoded !== null ? $decoded : $additionalInfo;
                }

                // Check if response triggers exclusion
                $triggersExclusion = $question->triggersExclusion($response ?? '');

                // Update or create response
                \App\Models\MedicalQuestionResponse::updateOrCreate(
                    [
                        'client_id' => $client->id,
                        'medical_question_id' => $questionId,
                    ],
                    [
                        'response' => $response,
                        'additional_info' => is_array($additionalInfo) ? $additionalInfo : ($additionalInfo ? json_decode($additionalInfo, true) : null),
                        'triggers_exclusion' => $triggersExclusion,
                    ]
                );
            }
        }

        // Check if client has exclusions
        $hasExclusions = $client->fresh()->hasExclusions();
        $successMessage = 'Client updated successfully.';
        
        if ($hasExclusions) {
            $successMessage .= ' WARNING: This client has responses that trigger exclusion list criteria.';
        }

        return redirect()->route('clients.index')
            ->with('success', $successMessage)
            ->with('has_exclusions', $hasExclusions);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Client $client)
    {
        // Check if client has policies
        if ($client->policies()->count() > 0) {
            return redirect()->route('clients.index')
                ->with('error', 'Cannot delete client with existing policies. Please remove policies first.');
        }

        // Check if client has dependents
        if ($client->dependents()->count() > 0) {
            return redirect()->route('clients.index')
                ->with('error', 'Cannot delete principal member with dependents. Please remove dependents first.');
        }

        $client->delete();

        return redirect()->route('clients.index')
            ->with('success', 'Client deleted successfully.');
    }
}
